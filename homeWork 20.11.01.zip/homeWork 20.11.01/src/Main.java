import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите числа ");
        float num1 = scr.nextFloat();
        float num2 = scr.nextFloat();
        int num3 = 10;

        if (Math.abs(num3 - num1) > Math.abs(num3 - num2))
            System.out.println("ближайшее число " + num2);

        if (Math.abs(num3 - num1) < Math.abs(num3 - num2))
            System.out.println("ближайшее число " + num1);

            if (Math.abs(num3 - num1) == Math.abs(num3 - num2))
                System.out.println("числа на одинаковом расстоянии ");

                else System.out.println("");
            }
        }

